'use strict';

import {
    isUndefined,
    isDefined,
    isInvalid,
    isStringOrNumber,
    isNullOrUndef,
    isArray,
    toArray
} from './NeactUtils';

import {
    isElementVNode,
    isComponentVNode,
    isTextVNode,
    isVoidVNode,
    isVNode,
    isSameVNode
} from './NeactElement';

import {
    mount,
    mountArrayChildren
} from './NeactMount';

import { unmount } from './NeactUnmount';

import {
    insertBefore,
    nextSibling,
    replaceWithNewNode,
    replaceVNode,
    setTextContent
} from './NeactDOMUtils';


export function patch(lastVNode, nextVNode, parentDom, lifecycle, context, isSVG) {
    if (lastVNode !== nextVNode) {

        if (!isSameVNode(lastVNode, nextVNode)) {
            replaceWithNewNode(
                lastVNode,
                nextVNode,
                parentDom,
                lifecycle,
                context,
                isSVG
            );
        } else if (isElementVNode(lastVNode)) {
            patchElement(lastVNode, nextVNode, parentDom, lifecycle, context, isSVG);
        } else if (isComponentVNode(lastVNode)) {
            patchComponent(lastVNode, nextVNode, parentDom, lifecycle, context, isSVG);
        } else if (isTextVNode(lastVNode)) {
            patchText(lastVNode, nextVNode);
        } else if (isVoidVNode(lastVNode)) {
            patchVoid(lastVNode, nextVNode);
        }
    }

    return nextVNode;
}

function createKeyToOldIdx(children, beginIdx, endIdx) {
    var i, map = {},
        key;
    for (i = beginIdx; i <= endIdx; ++i) {
        key = children[i].key;
        if (isDefined(key)) map[key] = i;
    }
    return map;
}

function unmountChildren(children, dom) {
    if (isVNode(children)) {
        unmount(children, dom);
    } else if (isArray(children)) {
        for (let i = 0; i < children.length; i++) {
            const child = children[i];

            if (!isInvalid(child)) {
                unmount(child, dom);
            }
        }
    } else {
        setTextContent(dom, '');
    }
}

function patchElement(lastVNode, nextVNode, parentDom, lifecycle, context, isSVG) {
    const dom = lastVNode.dom;
    const lastProps = lastVNode.props;
    const nextProps = nextVNode.props;
    const lastChildren = lastVNode.children;
    const nextChildren = nextVNode.children;
    const lastRef = lastVNode.ref;
    const nextRef = nextVNode.ref;
    const lastEvents = lastVNode.events;
    const nextEvents = nextVNode.events;

    nextVNode.dom = dom;

    if (lastChildren !== nextChildren) {
        patchChildren(lastChildren, nextChildren, dom, lifecycle, context, isSVG);
    }
    /*
    if (!(nextFlags & VNodeFlags.HtmlElement)) {
        processElement(nextFlags, nextVNode, dom);
    }
    if (lastProps !== nextProps) {
        patchProps(
            lastProps,
            nextProps,
            dom,
            lifecycle,
            context,
            isSVG
        );
    }
    if (lastEvents !== nextEvents) {
        patchEvents(lastEvents, nextEvents, dom, lifecycle);
    }
    if (nextRef) {
        if (lastRef !== nextRef || isRecycling) {
            mountRef(dom, nextRef, lifecycle);
        }
    }
    */
}

function patchChildren(lastChildren, nextChildren, dom, lifecycle, context, isSVG) {
    if (isInvalid(nextChildren)) {
        unmountChildren(lastChildren, dom, lifecycle);
    } else if (isInvalid(lastChildren)) {
        if (isArray(nextChildren)) {
            mountArrayChildren(nextChildren, dom, lifecycle, context, isSVG);
        } else {
            mount(nextChildren, dom, lifecycle, context, isSVG);
        }
    } else if (!isArray(lastChildren) && !isArray(nextChildren)) {
        patch(lastChildren, nextChildren, dom, lifecycle, context, isSVG);
    } else {
        updateChildren(toArray(lastChildren), toArray(nextChildren), dom, lifecycle, context, isSVG);
    }
}

function updateChildren(oldCh, newCh, parentElm, lifecycle, context, isSVG) {
    var oldStartIdx = 0,
        newStartIdx = 0;
    var oldEndIdx = oldCh.length - 1;
    var oldStartVnode = oldCh[0];
    var oldEndVnode = oldCh[oldEndIdx];
    var newEndIdx = newCh.length - 1;
    var newStartVnode = newCh[0];
    var newEndVnode = newCh[newEndIdx];
    var oldKeyToIdx, idxInOld, elmToMove, before;

    var newChilds = Array(newCh.length);

    while (oldStartIdx <= oldEndIdx && newStartIdx <= newEndIdx) {
        if (isUndefined(oldStartVnode)) {
            oldStartVnode = oldCh[++oldStartIdx]; // Vnode has been moved left
        } else if (isUndefined(oldEndVnode)) {
            oldEndVnode = oldCh[--oldEndIdx];
        } else if (isSameVNode(oldStartVnode, newStartVnode)) {
            patch(oldStartVnode, newStartVnode, parentElm, lifecycle, context, isSVG);
            //newChilds[newStartIdx] = oldStartVnode;
            oldStartVnode = oldCh[++oldStartIdx];
            newStartVnode = newCh[++newStartIdx];
        } else if (isSameVNode(oldEndVnode, newEndVnode)) {
            patch(oldEndVnode, newEndVnode, parentElm, lifecycle, context, isSVG);
            //newChilds[newEndIdx] = oldEndVnode;
            oldEndVnode = oldCh[--oldEndIdx];
            newEndVnode = newCh[--newEndIdx];
        } else if (isSameVNode(oldStartVnode, newEndVnode)) { // Vnode moved right
            patch(oldStartVnode, newEndVnode, parentElm, lifecycle, context, isSVG);
            insertBefore(parentElm, oldStartVnode.dom, nextSibling(oldEndVnode.dom));
            //newChilds[newEndIdx] = oldStartVnode;
            oldStartVnode = oldCh[++oldStartIdx];
            newEndVnode = newCh[--newEndIdx];
        } else if (isSameVNode(oldEndVnode, newStartVnode)) { // Vnode moved left
            patch(oldEndVnode, newStartVnode, parentElm, lifecycle, context, isSVG);
            insertBefore(parentElm, oldEndVnode.dom, oldStartVnode.dom);
            //newChilds[newStartIdx] = oldEndVnode;
            oldEndVnode = oldCh[--oldEndIdx];
            newStartVnode = newCh[++newStartIdx];
        } else {
            if (isUndefined(oldKeyToIdx)) oldKeyToIdx = createKeyToOldIdx(oldCh, oldStartIdx, oldEndIdx);

            idxInOld = oldKeyToIdx[newStartVnode.key];

            if (isUndefined(idxInOld) || isUndefined(oldCh[idxInOld])) { // New element
                var dom = mount(newCh[newStartIdx], null, lifecycle, context, isSVG);
                insertBefore(parentElm, dom, oldStartVnode.dom);
                //newChilds[newStartIdx] = vnode;
                newStartVnode = newCh[++newStartIdx];
            } else {
                elmToMove = oldCh[idxInOld];
                patch(elmToMove, newStartVnode, parentElm, lifecycle, context, isSVG);
                oldCh[idxInOld] = undefined;
                insertBefore(parentElm, elmToMove.dom, oldStartVnode.dom);
                //newChilds[newStartIdx] = elmToMove;
                newStartVnode = newCh[++newStartIdx];
            }
        }
    }

    if (oldStartIdx > oldEndIdx) { // New element
        before = isUndefined(newCh[newEndIdx + 1]) ? null : newCh[newEndIdx + 1].dom;
        for (; newStartIdx <= newEndIdx; newStartIdx++) {
            var dom = mount(newCh[newStartIdx], null, lifecycle, context, isSVG);
            insertBefore(parentElm, dom, before);
        }
    } else if (newStartIdx > newEndIdx) { // Remove element
        for (; oldStartIdx <= oldEndIdx; oldStartIdx++) {

            if (isDefined(oldCh[oldStartIdx])) {
                unmount(oldCh[oldStartIdx], parentElm);
            }
        }
    }
}

function patchComponent(prevComponent, nextElement) {}

function patchText(lastVNode, nextVNode) {
    const nextText = nextVNode.children;
    const dom = lastVNode.dom;

    nextVNode.dom = dom;

    if (lastVNode.children !== nextText) {
        dom.nodeValue = nextText;
    }
}

function patchVoid(lastVNode, nextVNode) {
    nextVNode.dom = lastVNode.dom;
}