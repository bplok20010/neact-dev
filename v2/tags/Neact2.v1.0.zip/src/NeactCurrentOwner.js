'use strict';

export var NeactCurrentOwner = {
    current: null
};