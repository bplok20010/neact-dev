'use strict';
import {
    isVNode,
    isElementVNode,
    isTextVNode,
    isVoidVNode
} from './NeactElement';

import {
    isString,
    isNull,
    isStringOrNumber,
    isArray,
    isInvalid
} from './NeactUtils';

import {
    documentCreateElement,
    appendChild
} from './NeactDOMUtils';

export function mount(vNode, parentDom, lifecycle, context, isSVG) {
    if (isElementVNode(vNode)) {
        return mountElement(vNode, parentDom, lifecycle, context, isSVG);
    } else if (isTextVNode(vNode)) {
        return mountText(vNode, parentDom);
    } else if (!isString(vNode.type)) {
        return mountComponent(vNode, parentDom, lifecycle, context, isSVG);
    } else if (isVoidVNode(vNode)) {
        return mountVoid(vNode, parentDom);
    } else {
        if (process.env.NODE_ENV !== 'production') {
            if (typeof vNode === 'object') {
                throwError(`mount() received an object that's not a valid VNode, you should stringify it first. Object: "${ JSON.stringify(vNode) }".`);
            } else {
                throwError(`mount() expects a valid VNode, instead it received an object with the type "${ typeof vNode }".`);
            }
        }
        throwError();
    }
}

export function mountText(vNode, parentDom) {
    const dom = document.createTextNode(vNode.children);

    vNode.dom = dom;
    if (parentDom) {
        appendChild(parentDom, dom);
    }
    return dom;
}

export function mountVoid(vNode, parentDom) {
    const dom = document.createComment('emptyNode');

    vNode.dom = dom;
    if (parentDom) {
        appendChild(parentDom, dom);
    }
    return dom;
}

export function mountElement(vNode, parentDom, lifecycle, context, isSVG) {
    const tag = vNode.type;

    if (!isSVG) {
        isSVG = vNode.isSVG;
    }

    const dom = documentCreateElement(tag, isSVG);
    const children = vNode.children;
    const props = vNode.props;
    const events = vNode.events;
    const ref = vNode.ref;

    vNode.dom = dom;
    if (!isNull(children)) {
        if (isArray(children)) {
            mountArrayChildren(children, dom, lifecycle, context, isSVG);
        } else if (isVNode(children)) {
            mount(children, dom, lifecycle, context, isSVG);
        }
    }
    //Test
    if (!isNull(events)) {
        $(dom).on(events);
    }
    if (!isNull(props)) {
        for (let prop in props) {
            if (prop === 'style') {
                $(dom).css(props[prop]);
            } else {
                $(dom).attr(prop, props[prop]);
            }
        }
    }
    /*
    if (!(flags & VNodeFlags.HtmlElement)) {
        processElement(flags, vNode, dom);
    }
    if (!isNull(props)) {
        for (let prop in props) {
            // do not add a hasOwnProperty check here, it affects performance
            patchProp(prop, null, props[prop], dom, isSVG, lifecycle);
        }
    }
    if (!isNull(events)) {
        for (let name in events) {
            // do not add a hasOwnProperty check here, it affects performance
            patchEvent(name, null, events[name], dom, lifecycle);
        }
    }
    if (!isNull(ref)) {
        mountRef(dom, ref, lifecycle);
    }
    */
    if (!isNull(parentDom)) {
        appendChild(parentDom, dom);
    }
    return dom;
}

export function mountArrayChildren(children, dom, lifecycle, context, isSVG) {
    for (let i = 0; i < children.length; i++) {
        let child = children[i];

        if (!isInvalid(child)) {
            //一般不会出现
            if (child.dom) {
                children[i] = child = cloneVNode(child);
            }
            mount(children[i], dom, lifecycle, context, isSVG);
        }
    }
}

export function mountComponent(vNode, parentDom, lifecycle, context, isSVG) {

}