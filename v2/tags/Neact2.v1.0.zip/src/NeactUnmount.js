'use strict';
import { removeChild } from './NeactDOMUtils';

export function unmount(vNode, parentDom) {
    if (parentDom) {
        removeChild(parentDom, vNode.dom);
    }
}