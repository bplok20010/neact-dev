'use strict';

import {
    createElement
} from './NeactElement';

import {
    mount
} from './NeactMount';

import {
    patch
} from './patch';

var utils = require('./NeactUtils')

function render(vNode, parentDom) {
    return mount(vNode, parentDom);
}

export {
    render,
    patch,
    createElement,
    utils
}