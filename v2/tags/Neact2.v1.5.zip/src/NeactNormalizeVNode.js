'use strict';

import {
    isString,
    isStringOrNumber,
    isInvalid,
    isArray,
    isNull
} from './NeactUtils';

import {
    createTextVNode,
    isVNode,
    isElementVNode
} from './NeactElement';


export function normalizeVNodes(nodes) {
    let newNodes = [];

    for (let i = 0; i < nodes.length; i++) {
        let n = nodes[i];
        if (isInvalid(n)) continue;
        if (isStringOrNumber(n)) {
            n = createTextVNode(n);
        }
        newNodes.push(n);
    }

    return newNodes.length > 0 ? newNodes : null;
}

function normalizeChildren(children) {
    if (isArray(children)) {
        return normalizeVNodes(children);
    } else if (isStringOrNumber(children)) {
        return createTextVNode(children)
    }
    return children;
}

export function normalize(vNode) {
    const props = vNode.props;
    const hasProps = !isNull(props);

    if (hasProps && !isInvalid(props.children)) {
        props.children = normalizeChildren(props.children);
    }

    if (isElementVNode(vNode)) {
        vNode.children = props.children;
        delete props.children;
    }
}