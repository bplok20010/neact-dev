'use strict';

import {
    isArray,
    isString,
    isFunction,
    isInvalid,
    isObject,
    isAttrAnEvent,
    isNullOrUndef,
    flatten,
    throwError
} from './NeactUtils';

import {
    ieVersion,
    isIE
} from './support';

import NeactCurrentOwner from './NeactCurrentOwner';

import {
    normalize
} from './NeactNormalizeVNode';

var hasOwnProperty = Object.prototype.hasOwnProperty;

export function isVNode(VNode) {
    return VNode && isObject(VNode) && VNode.$$isVNode;
}

export var isValidElement = isVNode;

export function isSameVNode(vnode1, vnode2) {
    var isSame = vnode1.key === vnode2.key && vnode1.type === vnode2.type;
    if (isSame && isIE && ieVersion < 9 && vnode1.dom.tagName.toLowerCase() === 'input') {
        isSame = false;
    }
    return isSame;
}

export function isVoidVNode(vNode) {
    return vNode.type === '#comment';
}

export function isTextVNode(vNode) {
    return vNode.type === '#text';
}

export function isElementVNode(vNode) {
    return isString(vNode.type) && vNode.type[0] !== '#';
}

export function isComponentVNode(vNode) {
    return !isString(vNode.type); // && isFunction(vNode.type)
}

export function createVNode(
    type,
    children = null,
    props = null,
    events = null,
    hooks = null,
    ref = null,
    key = null,
    isSVG = false,
    owner = null,
    noNormalise = false
) {
    var vNode = {
        $$isVNode: true,
        type: type,
        key: key,
        ref: ref,
        props: props,
        isSVG: isSVG,
        children: children,
        events: events,
        hooks: hooks,
        dom: null,
        _owner: owner
    };

    if (!noNormalise) {
        normalize(vNode);
    }

    return vNode;
}

export function createVoidVNode() {
    return createVNode('#comment');
}

export var createComment = createVoidVNode;

export function createTextVNode(text) {
    return createVNode('#text', text, null, null, null, null, null, false, null, true);
}

export var createTextNode = createTextVNode;

export function createElement(type, config, ..._children) {
    if (isInvalid(type) || isObject(type)) {
        throw new Error('Neact Error: createElement() type parameter cannot be undefined, null, false or true, It must be a string, class or function.');
    }
    let prop, children = flatten(_children),
        props = {},
        events = null,
        hooks = null,
        key = null,
        ref = null,
        isSVG = false;

    if (children.length === 1) {
        children = children[0];
    } else if (children.length === 0) {
        children = null;
    }

    if (!isNullOrUndef(config)) {
        for (prop in config) {
            //if (hasOwnProperty.call(config, prop)) {
            if (prop === 'key') {
                key = '' + config.key;
            } else if (prop === 'ref') {
                ref = '' + config.ref;
            } else if (prop === 'hooks') {
                hooks = config.hooks;
            } else if (isAttrAnEvent(prop) && isString(type)) {
                if (!events) {
                    events = {};
                }
                events[prop.toLowerCase()] = config[prop];
            } else {
                props[prop] = config[prop];
            }
            //}
        }
    }

    //ComponentClass ComponentFunction
    if (!isString(type)) {
        if (type.defaultProps) {
            let defaultProps = type.defaultProps;
            for (prop in defaultProps) {
                if (props[prop] === undefined) {
                    props[prop] = defaultProps[prop];
                }
            }
        }
    }

    props.children = children;

    if (type && type[0] === 's' && type[1] === 'v' && type[2] === 'g') {
        isSVG = true;
    }

    return createVNode(type, null, props, events, hooks, ref, key, isSVG, NeactCurrentOwner.current);
}

export function cloneElement(type, config, children) {
    throwError('waiting...');
}