'use strict';
import {
    warning,
    throwError,
    isInvalid
} from './NeactUtils';

import {
    mount
} from './NeactMount';

import {
    isVNode
} from './NeactElement';

import {
    patch
} from './patch';

export function render(vNode, parentDom) {
    if (document.body === parentDom) {
        warning('you cannot render() to the "document.body". Use an empty element as a container instead.');
    }

    const lastVnode = parentDom.__NeactRootNode;

    if (!lastVnode) {
        if (!isInvalid(vNode) && isVNode(vNode)) {
            mount(vNode, parentDom);
            parentDom.__NeactRootNode = vNode;
            return vNode._instance || vNode.dom;
        } else {
            throwError('isInvalid VNode');
        }
    } else {
        if (isInvalid(vNode)) {
            unmount(lastVnode, parentDom);
            parentDom.__NeactRootNode = null;
            delete parentDom.__NeactRootNode;
        } else if (isVNode(vNode)) {
            patch(lastVnode, vNode);
            parentDom.__NeactRootNode = vNode;
            return vNode._instance || vNode.dom;
        } else {
            throwError('isInvalid VNode');
        }
    }
}

export function unmountComponentAtNode(node) {
    if (node.__NeactRootNode) {
        unmount(dom.__NeactRootNode, node);
        delete dom.__NeactInstance;
    }
}

export function findDOMNode(vNode) {
    if (!isInvalid(isVNode)) {
        if (isVNode(vNode)) {
            return vNode.dom;
        } else if (vNode._vNode) {
            return vNode._vNode.dom;
        }
    }
    return null
}