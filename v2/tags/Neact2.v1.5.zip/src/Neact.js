'use strict';

import {
    render,
    findDOMNode,
    unmountComponentAtNode
} from './NeactRender';

import processDOMPropertyHooks from './processDOMPropertyHooks';

import {
    createElement,
    cloneElement,
    isValidElement
} from './NeactElement';

import {
    createClass
} from './NeactClass';

import NeactComponent from './NeactComponent';
import NeactPureComponent from './NeactPureComponent';

var utils = require('./NeactUtils');

export {
    render,
    findDOMNode,
    unmountComponentAtNode,
    createElement,
    cloneElement,
    isValidElement,
    processDOMPropertyHooks,
    createClass,
    NeactComponent as Component,
    NeactPureComponent as PureComponent,
    utils
}