'use strict';
import {
    isNullOrUndef,
    isString,
    isNumber,
    emptyObject
} from '../NeactUtils';

import {
    isUnitlessNumber,
    styleFloatAccessor,
    hasShorthandPropertyBug,
    shorthandPropertyExpansions
} from './constants';

export default function(lastValue, nextValue, prop, isSVG, dom, vNode) {
    if (lastValue === nextValue) return;
    if (isString(nextValue)) {
        dom.style.cssText = nextValue;
        return;
    }

    let styles = {};

    lastValue = lastValue || emptyObject;
    nextValue = nextValue || emptyObject;

    for (let style in nextValue) {
        // do not add a hasOwnProperty check here, it affects performance
        const value = nextValue[style];
        styles[style] = value;
    }

    for (const style in lastValue) {
        if (isNullOrUndef(nextValue[style])) {
            styles[style] = '';
        }
    }

    var style = dom.style;
    for (var styleName in styles) {
        //if (!styles.hasOwnProperty(styleName)) {
        //    continue;
        //}

        var styleValue = dangerousStyleValue(styleName, styles[styleName]);
        if (styleName === 'float' || styleName === 'cssFloat') {
            styleName = styleFloatAccessor;
        }
        if (styleValue) {
            style[styleName] = styleValue;
        } else {
            var expansion = hasShorthandPropertyBug && shorthandPropertyExpansions[styleName];
            if (expansion) {
                // Shorthand property that IE8 won't like unsetting, so unset each
                // component to placate it
                for (var individualStyleName in expansion) {
                    style[individualStyleName] = '';
                }
            } else {
                style[styleName] = '';
            }
        }
    }
}

/**
 * Convert a value into the proper css writable value. The style name `name`
 * should be logical (no hyphens), as specified
 * in `CSSProperty.isUnitlessNumber`.
 *
 * @param {string} name CSS property name such as `topMargin`.
 * @param {*} value CSS property value such as `10px`.
 * @param {ReactDOMComponent} component
 * @return {string} Normalized style value with dimensions applied.
 */
function dangerousStyleValue(name, value) {
    // Note that we've removed escapeTextForBrowser() calls here since the
    // whole string will be escaped when the attribute is injected into
    // the markup. If you provide unsafe user data here they can inject
    // arbitrary CSS which may be problematic (I couldn't repro this):
    // https://www.owasp.org/index.php/XSS_Filter_Evasion_Cheat_Sheet
    // http://www.thespanner.co.uk/2007/11/26/ultimate-xss-css-injection/
    // This is not an XSS hole but instead a potential CSS injection issue
    // which has lead to a greater discussion about how we're going to
    // trust URLs moving forward. See #2115901

    var isEmpty = value == null || typeof value === 'boolean' || value === '';
    if (isEmpty) {
        return '';
    }

    var isNonNumeric = isNaN(value);
    if (isNonNumeric || value === 0 || isUnitlessNumber[name]) {
        return '' + value; // cast to string
    }

    if (typeof value === 'string') {
        value = value.trim();
    }
    return value + 'px';
}