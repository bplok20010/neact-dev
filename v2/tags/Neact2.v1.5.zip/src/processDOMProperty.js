'use strict';
import {
    addEventListener,
    removeEventListener
} from './NeactDOMUtils';

import {
    isUndefined,
    isNullOrUndef,
    emptyObject,
    assign
} from './NeactUtils';

import processDOMPropertyHooks from './processDOMPropertyHooks';

import processDOMStyle from './hooks/processDOMStyle';
import processDOMAttr from './hooks/processDOMAttr';

const propertyHooks = assign({
    style: processDOMStyle,
    __default__: processDOMAttr
}, processDOMPropertyHooks);

export function createDOMProperty(props, isSVG, vNode) {
    updateDOMProperty(null, props, isSVG, vNode);
}

export function updateDOMProperty(lastProps, nextProps, isSVG, vNode) {
    if (lastProps === nextProps) {
        return;
    }

    const dom = vNode.dom;

    lastProps = lastProps || emptyObject;
    nextProps = nextProps || emptyObject;

    if (nextProps !== emptyObject) {
        for (let prop in nextProps) {
            // do not add a hasOwnProperty check here, it affects performance
            const nextValue = isNullOrUndef(nextProps[prop]) ? null : nextProps[prop];
            const lastValue = isNullOrUndef(lastProps[prop]) ? null : lastProps[prop];
            const hook = propertyHooks[prop] ? prop : '__default__';
            propertyHooks[hook](lastValue, nextValue, prop, isSVG, dom, vNode);
        }
    }
    if (lastProps !== emptyObject) {
        for (let prop in lastProps) {
            if (isNullOrUndef(nextProps[prop])) {
                const lastValue = isNullOrUndef(lastProps[prop]) ? null : lastProps[prop];
                const hook = propertyHooks[prop] ? prop : '__default__';
                propertyHooks[hook](lastValue, null, prop, isSVG, dom, vNode);
            }
        }
    }
}

function ename(s) {
    return s.replace('on', '');
}

export function createDOMEvents(events, vNode) {
    if (!events) return;
    const dom = vNode.dom;
    dom.__NeactEvents = events;
    dom.__listener = createListener(vNode);
    for (let name in events) {
        addEventListener(dom, ename(name), dom.__listener);
    }
}

export function updateDOMEvents(lastEvents, nextEvents, vNode) {
    if (lastEvents === nextEvents) {
        return;
    }

    const dom = vNode.dom;
    let listener = dom.__listener;
    dom.__NeactEvents = nextEvents;

    if (lastEvents && listener) {
        // if element changed or deleted we remove all existing listeners unconditionally
        if (!nextEvents) {
            for (name in lastEvents) {
                removeEventListener(dom, ename(name), listener);
            }
        } else {
            for (name in lastEvents) {
                // remove listener if existing listener removed
                if (!nextEvents[name]) {
                    removeEventListener(dom, ename(name), listener);
                }
            }
        }
    }

    if (nextEvents) {
        // reuse existing listener or create new
        if (!listener) {
            dom.__listener = listener = createListener(vNode);
        }

        // if element changed or added we add all needed listeners unconditionally
        if (!lastEvents) {
            for (name in nextEvents) {
                // add listener if element was changed or new listeners added
                addEventListener(dom, ename(name), listener);
            }
        } else {
            for (name in nextEvents) {
                // add listener if new listener added
                if (!lastEvents[name]) {
                    addEventListener(dom, ename(name), listener);
                }
            }
        }
    }

}

function createListener(vNode) {
    return function(e) {
        handleEvent(e, vNode);
    }
}

function handleEvent(e, vNode) {
    e = e || event;
    const name = 'on' + event.type;
    const dom = vNode.dom;
    const events = dom.__NeactEvents;

    if (!events) return;

    if (events && events[name]) {
        events[name].call(dom, e, vNode);
    }
}