class A {
    constructor() {

    }
    alert() {
        console.log(1222)
    }
}

class B extends A {

}