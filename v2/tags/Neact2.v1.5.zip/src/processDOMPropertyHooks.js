'use strict';
let processDOMPropertyHooks = {

};
export default processDOMPropertyHooks;