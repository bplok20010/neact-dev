'use strict';

let NeactCurrentOwner = {
    current: null
};

export default NeactCurrentOwner;