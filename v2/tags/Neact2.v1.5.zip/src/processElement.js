'use strict';

export default function processElement(vNode, dom) {

}