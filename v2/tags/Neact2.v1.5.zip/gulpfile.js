var gulp = require("gulp");
var browserify = require("browserify");
var source = require("vinyl-source-stream");
var path = require('path');

var babel = require("gulp-babel");

var babelify = require('babelify');
var rename = require('gulp-rename');
var uglify = require('gulp-uglify');
var streamify = require('gulp-streamify');

gulp.task("JSX", function() {
    gulp.src("./examples/**/*.jsx")
        .pipe(babel({
            presets: ["babel-preset-es2015", "babel-preset-stage-0", "babel-preset-react"],
            "plugins": [
                ["transform-es2015-classes", { "loose": true }]
            ]
        }))
        .on('error', function(err) {
            console.log(err);
        })
        .pipe(gulp.dest('./examples'));
});

gulp.task("compile", function() {
    gulp.src("./src/**/*.js")
        .pipe(babel({
            presets: ["babel-preset-es2015", "babel-preset-stage-0"],
            "plugins": [
                "transform-es3-property-literals",
                "transform-es3-member-expression-literals", ['transform-es2015-modules-commonjs', { "loose": true }],
                //'transform-runtime', ["transform-es2015-classes", { "loose": true }]
            ]
        }))
        .on('error', function(err) {
            console.log(err);
        })
        .pipe(gulp.dest('./dist/src'));
});

gulp.task("build", function() {
    browserify({
            entries: ["./src/Neact.js"],
            standalone: 'Neact'
        })
        .transform(babelify, {
            presets: ["babel-preset-es2015", "babel-preset-stage-0"],
            "plugins": [
                "transform-es3-property-literals",
                "transform-es3-member-expression-literals",
                //'transform-runtime', ["transform-es2015-classes", { "loose": false }],
                ['transform-es2015-modules-commonjs', { "loose": true }]
            ]
        })
        .bundle()
        .pipe(source("Neact.js"))
        .pipe(gulp.dest("./dist"))
        .pipe(rename({ suffix: '.min' }))
        .pipe(streamify(uglify()))
        .pipe(gulp.dest('./dist'));
});

//gulp默认命令
gulp.task("default", ["build", 'compile', 'JSX']);

gulp.watch(["./src/*.js"], function() {
    gulp.run('build');
    gulp.run('compile');
});

gulp.watch(["./examples/**/*.jsx"], function() {
    gulp.run('JSX');
});