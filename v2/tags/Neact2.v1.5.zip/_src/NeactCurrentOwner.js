'use strict';

var NeactCurrentOwner = {
    current: null
};

module.exports = NeactCurrentOwner;